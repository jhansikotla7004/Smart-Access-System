/**
 * @file    main.c
 * @brief   Smart Access Security System — STM32 NUCLEO-L432KC
 * @author  Kotla Jhansi Lakshmi  (A00046968)
 * @module  EENG1030 Embedded Systems
 * @date    May 2026
 *
 * @details
 *   Firmware for a PIN-based door-lock demonstrator.
 *   Peripherals:
 *     - ST7735 1.8" TFT display via SPI1  (PA4/PA5/PA6/PA7, RST=PA0)
 *     - Active buzzer                      (PA1)
 *     - 3×4 matrix keypad                  (PB0,PB4,PB5,PB6 / PA8,PA9,PA10)
 *     - UART2 serial monitor               (PA2 TX, PA3 RX, 115200 baud)
 *
 *   State machine:
 *     HOME → PIN_ENTRY → GRANTED / DENIED → HOME
 *     Three consecutive wrong PINs → LOCKED (hardware reset required)
 *
 *   HAL library: STM32Cube L4 (PlatformIO / STM32duino framework)
 */

#include "stm32l4xx_hal.h"
#include <string.h>
#include <stdio.h>

/* ── Forward declarations ───────────────────────────────────────────────── */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART2_UART_Init(void);

void ST7735_Init(void);
void ST7735_FillScreen(uint16_t colour);
void ST7735_DrawString(uint8_t x, uint8_t y, const char *str,
                       uint16_t fg, uint16_t bg, uint8_t size);
void ST7735_WriteCommand(uint8_t cmd);
void ST7735_WriteData(uint8_t data);

void Screen_Home(void);
void Screen_Pin(uint8_t count);
void Screen_Granted(void);
void Screen_Denied(uint8_t attempts);
void Screen_Locked(void);
void Screen_Cleared(void);

void Keypad_Init(void);
char Keypad_Read(void);
void Set_Pin_Output_Low(uint8_t idx);
void Set_Pin_InputPullup(uint8_t idx);

void Beep(uint16_t ms);
void UART_Print(const char *msg);
void Access_Granted(void);
void Access_Denied(uint8_t *attempts);

/* ── RGB565 colour macros ───────────────────────────────────────────────── */
#define BLACK   0x0000
#define WHITE   0xFFFF
#define RED     0xF800
#define GREEN   0x07E0
#define BLUE    0x001F
#define YELLOW  0xFFE0
#define CYAN    0x07FF
#define NAVY    0x000F

/* ── Pin configuration ──────────────────────────────────────────────────── */
/* TFT control lines (all on GPIOA) */
#define TFT_CS_PIN   GPIO_PIN_4
#define TFT_DC_PIN   GPIO_PIN_6
#define TFT_RST_PIN  GPIO_PIN_0
#define TFT_PORT     GPIOA

/* Buzzer */
#define BUZ_PIN      GPIO_PIN_1
#define BUZ_PORT     GPIOA

/* Correct PIN length */
#define PIN_LENGTH   3

/* Maximum wrong attempts before lockout */
#define MAX_ATTEMPTS 3

/* ── Keypad wiring lookup ───────────────────────────────────────────────── */
/*
 * The 3×4 keypad has 7 wires.  Rather than the classic row/column approach
 * (which needs pull-up resistors and a clean pinout), a pair-scanning method
 * is used: each pair of wires is driven/sensed in turn.  The keyPairs table
 * maps a (drive, sense) index pair to the key character.
 *
 * Wire index → STM32 pin:
 *   0 = PB0   1 = PB4   2 = PB5   3 = PB6
 *   4 = PA8   5 = PA9   6 = PA10
 *
 * IMPORTANT: indices 7+ are reserved / do not map to keypad wires.
 * SPI pins (PA4, PA5, PA6, PA7) and UART pins (PA2, PA3) are protected
 * by a guard clause in Set_Pin_Output_Low / Set_Pin_InputPullup.
 */
static GPIO_TypeDef * const keyPorts[7] = {
    GPIOB, GPIOB, GPIOB, GPIOB,  /* PB0 PB4 PB5 PB6 */
    GPIOA, GPIOA, GPIOA           /* PA8 PA9 PA10     */
};
static const uint16_t keyPins[7] = {
    GPIO_PIN_0, GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6,
    GPIO_PIN_8, GPIO_PIN_9, GPIO_PIN_10
};

/*
 * Pair table: keyPairs[drive][sense] = key character.
 * Populated by physical calibration of this specific keypad module.
 * '0' entries indicate invalid combinations.
 */
static const char keyPairs[7][7] = {
    /* sense: 0     1     2     3     4     5     6  */
    /* drv 0 */ { 0,  '1',  '2',  '3',   0,    0,    0   },
    /* drv 1 */ {'1',  0,   '4',  '5',   0,    0,    0   },
    /* drv 2 */ {'2', '4',   0,   '7',  '0',   0,    0   },
    /* drv 3 */ {'3', '5',  '7',   0,   '#',   0,    0   },
    /* drv 4 */ { 0,   0,   '0',  '#',   0,   '6',  '8'  },
    /* drv 5 */ { 0,   0,    0,    0,   '6',   0,   '9'  },
    /* drv 6 */ { 0,   0,    0,    0,   '8',  '9',   0   },
};

/* ── HAL handles ────────────────────────────────────────────────────────── */
SPI_HandleTypeDef  hspi1;
UART_HandleTypeDef huart2;

/* ── Entry point ────────────────────────────────────────────────────────── */
int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI1_Init();
    MX_USART2_UART_Init();

    ST7735_Init();
    Keypad_Init();

    /* Startup indication */
    Beep(200);
    UART_Print("Smart Access System Ready\r\nEnter PIN: ");
    Screen_Home();

    uint8_t pinBuf[PIN_LENGTH];
    uint8_t pinCount    = 0;
    uint8_t wrongAttempts = 0;
    uint8_t locked      = 0;

    while (1)
    {
        if (locked) continue;   /* Hard lockout — only reset clears this */

        char key = Keypad_Read();
        if (key == 0) continue;

        /* ── Clear / reset key ────────────────────────────────────────── */
        if (key == '*')
        {
            pinCount = 0;
            memset(pinBuf, 0, sizeof(pinBuf));
            Screen_Cleared();
            HAL_Delay(700);
            Screen_Home();
            UART_Print("\r\nPIN cleared\r\nEnter PIN: ");
            continue;
        }

        /* ── Digit accepted ───────────────────────────────────────────── */
        if (key >= '0' && key <= '9')
        {
            pinBuf[pinCount++] = (uint8_t)(key - '0');
            UART_Print("* ");
            Screen_Pin(pinCount);
            Beep(80);

            if (pinCount >= PIN_LENGTH)
            {
                /* Evaluate PIN — correct PIN is 1-1-1 for demo */
                uint8_t correct = (pinBuf[0] == 1 &&
                                   pinBuf[1] == 1 &&
                                   pinBuf[2] == 1) ? 1 : 0;

                pinCount = 0;
                memset(pinBuf, 0, sizeof(pinBuf));

                if (correct)
                {
                    wrongAttempts = 0;
                    Access_Granted();
                    UART_Print("\r\nEnter PIN: ");
                    Screen_Home();
                }
                else
                {
                    Access_Denied(&wrongAttempts);
                    if (wrongAttempts >= MAX_ATTEMPTS)
                    {
                        locked = 1;
                        Screen_Locked();
                        UART_Print("\r\n>> SYSTEM LOCKED\r\n");
                        /* Rapid warning beeps */
                        for (int i = 0; i < 5; i++) { Beep(100); HAL_Delay(80); }
                    }
                    else
                    {
                        HAL_Delay(1200);
                        UART_Print("\r\nEnter PIN: ");
                        Screen_Home();
                    }
                }
            }
            continue;
        }

        /* '#' key could be used as confirm in future — ignored for now */
    }
}

/* ══════════════════════════════════════════════════════════════════════════
 *  KEYPAD FUNCTIONS
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * @brief  Initialise all keypad wires as input with internal pull-up.
 */
void Keypad_Init(void)
{
    for (int i = 0; i < 7; i++) Set_Pin_InputPullup(i);
}

/**
 * @brief  Scan the keypad using pair-drive method.
 * @return ASCII key character, or 0 if no key detected.
 *
 * Each wire is driven LOW in turn while all others are set as pull-up inputs.
 * A pressed key creates a conductive path, pulling an input line LOW.
 * After detection a 50 ms debounce delay is applied, followed by a release
 * wait to prevent repeated registration.
 */
char Keypad_Read(void)
{
    for (int d = 0; d < 7; d++)
    {
        Set_Pin_Output_Low(d);

        for (int r = 0; r < 7; r++)
        {
            if (r == d) continue;
            Set_Pin_InputPullup(r);

            if (HAL_GPIO_ReadPin(keyPorts[r], keyPins[r]) == GPIO_PIN_RESET)
            {
                HAL_Delay(50);  /* debounce settle */

                /* Confirm still pressed */
                if (HAL_GPIO_ReadPin(keyPorts[r], keyPins[r]) == GPIO_PIN_RESET)
                {
                    char k = keyPairs[d][r];
                    if (k != 0)
                    {
                        /* Wait for release */
                        while (HAL_GPIO_ReadPin(keyPorts[r], keyPins[r]) == GPIO_PIN_RESET)
                            HAL_Delay(10);
                        HAL_Delay(30);  /* post-release settle */

                        Set_Pin_InputPullup(d);
                        return k;
                    }
                }
            }
        }
        Set_Pin_InputPullup(d);
    }
    return 0;
}

/**
 * @brief  Configure keypad wire [idx] as push-pull output, drive LOW.
 * @note   Guard clause: SPI1 and UART2 pins are never reconfigured.
 *         Protected pins: PA0, PA1, PA2, PA3, PA4, PA5, PA6, PA7.
 *         Keypad wires on PA8/PA9/PA10 are safe to reconfigure.
 */
void Set_Pin_Output_Low(uint8_t idx)
{
    if (idx >= 7) return;
    /* Protect SPI1/UART2/TFT-control pins on PA0–PA7 */
    if (keyPorts[idx] == GPIOA && keyPins[idx] <= GPIO_PIN_7) return;

    GPIO_InitTypeDef g = {0};
    g.Pin   = keyPins[idx];
    g.Mode  = GPIO_MODE_OUTPUT_PP;
    g.Pull  = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(keyPorts[idx], &g);
    HAL_GPIO_WritePin(keyPorts[idx], keyPins[idx], GPIO_PIN_RESET);
}

/**
 * @brief  Configure keypad wire [idx] as input with internal pull-up.
 * @note   Same SPI/UART guard clause as Set_Pin_Output_Low().
 */
void Set_Pin_InputPullup(uint8_t idx)
{
    if (idx >= 7) return;
    if (keyPorts[idx] == GPIOA && keyPins[idx] <= GPIO_PIN_7) return;

    GPIO_InitTypeDef g = {0};
    g.Pin  = keyPins[idx];
    g.Mode = GPIO_MODE_INPUT;
    g.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(keyPorts[idx], &g);
}

/* ══════════════════════════════════════════════════════════════════════════
 *  SCREEN STATES
 * ══════════════════════════════════════════════════════════════════════════ */

void Screen_Home(void)
{
    ST7735_FillScreen(BLACK);
    ST7735_DrawString(10,  10, "SECURE MODE",  CYAN,   BLACK, 1);
    ST7735_DrawString(15,  50, "ENTER PIN",    WHITE,  BLUE,  2);
    ST7735_DrawString(20,  90, "WELCOME",      GREEN,  BLACK, 1);
    ST7735_DrawString(10, 120, "SMART LOCK",   BLUE,   BLACK, 2);
}

void Screen_Pin(uint8_t count)
{
    /* Only redraw the asterisk row — avoids full-screen SPI overhead */
    char buf[PIN_LENGTH + 1];
    memset(buf, '*', count);
    buf[count] = '\0';
    ST7735_DrawString(20, 70, "           ", WHITE, BLACK, 2); /* clear row */
    ST7735_DrawString(20, 70, buf,           YELLOW, BLACK, 2);
}

void Screen_Granted(void)
{
    ST7735_FillScreen(GREEN);
    ST7735_DrawString(10, 30,  "ACCESS",    BLACK, GREEN, 2);
    ST7735_DrawString(10, 60,  "GRANTED",   BLACK, GREEN, 2);
    ST7735_DrawString(10, 100, "DOOR OPEN", BLACK, GREEN, 1);
}

void Screen_Denied(uint8_t attempts)
{
    char buf[24];
    ST7735_FillScreen(RED);
    ST7735_DrawString(10, 30, "ACCESS",  WHITE, RED, 2);
    ST7735_DrawString(10, 60, "DENIED",  WHITE, RED, 2);
    snprintf(buf, sizeof(buf), "Attempt %d/%d", attempts, MAX_ATTEMPTS);
    ST7735_DrawString(5, 100, buf, WHITE, RED, 1);
}

void Screen_Locked(void)
{
    ST7735_FillScreen(RED);
    ST7735_DrawString(5,  30, "SYSTEM",   WHITE, RED, 2);
    ST7735_DrawString(5,  60, "LOCKED",   WHITE, RED, 2);
    ST7735_DrawString(5, 100, "Reset MCU",WHITE, RED, 1);
}

void Screen_Cleared(void)
{
    ST7735_FillScreen(BLACK);
    ST7735_DrawString(10, 60, "PIN RESET", YELLOW, BLACK, 2);
}

/* ══════════════════════════════════════════════════════════════════════════
 *  ACCESS LOGIC
 * ══════════════════════════════════════════════════════════════════════════ */

void Access_Granted(void)
{
    Screen_Granted();
    UART_Print("\r\n>> ACCESS GRANTED\r\n");
    /* Three short beeps — distinct from denied pattern */
    for (int i = 0; i < 3; i++) { Beep(80); HAL_Delay(50); }
    HAL_Delay(1500);
}

void Access_Denied(uint8_t *attempts)
{
    (*attempts)++;
    Screen_Denied(*attempts);
    char buf[48];
    snprintf(buf, sizeof(buf), "\r\n>> ACCESS DENIED (Attempt %d of %d)\r\n",
             *attempts, MAX_ATTEMPTS);
    UART_Print(buf);
    /* Two rapid beeps */
    Beep(100); HAL_Delay(50); Beep(100);
}

/* ══════════════════════════════════════════════════════════════════════════
 *  BUZZER
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * @brief  Drive PA1 HIGH for [ms] milliseconds then LOW.
 *         Active buzzer contains internal oscillator — no PWM needed.
 */
void Beep(uint16_t ms)
{
    HAL_GPIO_WritePin(BUZ_PORT, BUZ_PIN, GPIO_PIN_SET);
    HAL_Delay(ms);
    HAL_GPIO_WritePin(BUZ_PORT, BUZ_PIN, GPIO_PIN_RESET);
}

/* ══════════════════════════════════════════════════════════════════════════
 *  UART
 * ══════════════════════════════════════════════════════════════════════════ */

void UART_Print(const char *msg)
{
    HAL_UART_Transmit(&huart2, (uint8_t *)msg, (uint16_t)strlen(msg), 100);
}

/* ══════════════════════════════════════════════════════════════════════════
 *  ST7735 DRIVER  (minimal — command/data/fill/string)
 * ══════════════════════════════════════════════════════════════════════════ */

static void TFT_CS_Low(void)  { HAL_GPIO_WritePin(TFT_PORT, TFT_CS_PIN,  GPIO_PIN_RESET); }
static void TFT_CS_High(void) { HAL_GPIO_WritePin(TFT_PORT, TFT_CS_PIN,  GPIO_PIN_SET);   }
static void TFT_DC_Low(void)  { HAL_GPIO_WritePin(TFT_PORT, TFT_DC_PIN,  GPIO_PIN_RESET); }
static void TFT_DC_High(void) { HAL_GPIO_WritePin(TFT_PORT, TFT_DC_PIN,  GPIO_PIN_SET);   }

void ST7735_WriteCommand(uint8_t cmd)
{
    TFT_DC_Low(); TFT_CS_Low();
    HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
    TFT_CS_High();
}

void ST7735_WriteData(uint8_t data)
{
    TFT_DC_High(); TFT_CS_Low();
    HAL_SPI_Transmit(&hspi1, &data, 1, HAL_MAX_DELAY);
    TFT_CS_High();
}

static void ST7735_SetAddrWindow(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1)
{
    ST7735_WriteCommand(0x2A);          /* CASET */
    ST7735_WriteData(0); ST7735_WriteData(x0);
    ST7735_WriteData(0); ST7735_WriteData(x1);

    ST7735_WriteCommand(0x2B);          /* RASET */
    ST7735_WriteData(0); ST7735_WriteData(y0);
    ST7735_WriteData(0); ST7735_WriteData(y1);

    ST7735_WriteCommand(0x2C);          /* RAMWR */
}

void ST7735_FillScreen(uint16_t colour)
{
    uint8_t hi = colour >> 8, lo = colour & 0xFF;
    ST7735_SetAddrWindow(0, 0, 127, 159);
    TFT_DC_High(); TFT_CS_Low();
    for (uint32_t i = 0; i < 128UL * 160UL; i++)
    {
        HAL_SPI_Transmit(&hspi1, &hi, 1, HAL_MAX_DELAY);
        HAL_SPI_Transmit(&hspi1, &lo, 1, HAL_MAX_DELAY);
    }
    TFT_CS_High();
}

/* Minimal 5×7 font — only printable ASCII subset needed for this project */
static const uint8_t font5x7[][5] = {
    {0x00,0x00,0x00,0x00,0x00}, /* space 0x20 */
    /* ... full font table omitted for brevity; use Adafruit GFX font array */
};

void ST7735_DrawString(uint8_t x, uint8_t y, const char *str,
                       uint16_t fg, uint16_t bg, uint8_t size)
{
    /*
     * Minimal stub — replace with full Adafruit GFX character renderer
     * or link against the ST7735 library included in lib/ folder.
     * This function signature matches the Adafruit ST7735 API so the
     * library can be dropped in without changing call sites.
     */
    (void)x; (void)y; (void)str; (void)fg; (void)bg; (void)size;
}

void ST7735_Init(void)
{
    /* Hardware reset */
    HAL_GPIO_WritePin(TFT_PORT, TFT_RST_PIN, GPIO_PIN_RESET);
    HAL_Delay(10);
    HAL_GPIO_WritePin(TFT_PORT, TFT_RST_PIN, GPIO_PIN_SET);
    HAL_Delay(120);

    ST7735_WriteCommand(0x01);  /* SWRESET */
    HAL_Delay(150);
    ST7735_WriteCommand(0x11);  /* SLPOUT  */
    HAL_Delay(255);

    /* Colour mode: 16-bit RGB565 */
    ST7735_WriteCommand(0x3A);
    ST7735_WriteData(0x05);

    /* Display orientation — normal portrait */
    ST7735_WriteCommand(0x36);
    ST7735_WriteData(0x00);

    ST7735_WriteCommand(0x29);  /* DISPON */
    HAL_Delay(100);
}

/* ══════════════════════════════════════════════════════════════════════════
 *  HAL PERIPHERAL INITIALISERS
 * ══════════════════════════════════════════════════════════════════════════ */

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    osc.OscillatorType = RCC_OSCILLATORTYPE_MSI;
    osc.MSIState       = RCC_MSI_ON;
    osc.MSICalibrationValue = 0;
    osc.MSIClockRange  = RCC_MSIRANGE_6;   /* 4 MHz */
    osc.PLL.PLLState   = RCC_PLL_ON;
    osc.PLL.PLLSource  = RCC_PLLSOURCE_MSI;
    osc.PLL.PLLM       = 1;
    osc.PLL.PLLN       = 40;               /* VCO = 160 MHz */
    osc.PLL.PLLP       = RCC_PLLP_DIV7;
    osc.PLL.PLLQ       = RCC_PLLQ_DIV2;
    osc.PLL.PLLR       = RCC_PLLR_DIV2;   /* SYSCLK = 80 MHz */
    HAL_RCC_OscConfig(&osc);

    clk.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                         RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV1;
    clk.APB2CLKDivider = RCC_HCLK_DIV1;
    HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_4);
}

static void MX_SPI1_Init(void)
{
    hspi1.Instance               = SPI1;
    hspi1.Init.Mode              = SPI_MODE_MASTER;
    hspi1.Init.Direction         = SPI_DIRECTION_2LINES;
    hspi1.Init.DataSize          = SPI_DATASIZE_8BIT;
    hspi1.Init.CLKPolarity       = SPI_POLARITY_LOW;
    hspi1.Init.CLKPhase          = SPI_PHASE_1EDGE;
    hspi1.Init.NSS               = SPI_NSS_SOFT;
    hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8; /* 80/8 = 10 MHz */
    hspi1.Init.FirstBit          = SPI_FIRSTBIT_MSB;
    hspi1.Init.TIMode            = SPI_TIMODE_DISABLE;
    hspi1.Init.CRCCalculation    = SPI_CRCCALCULATION_DISABLE;
    HAL_SPI_Init(&hspi1);
}

static void MX_USART2_UART_Init(void)
{
    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart2);
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef g = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* Default output state */
    HAL_GPIO_WritePin(GPIOA,
        TFT_CS_PIN | TFT_DC_PIN | TFT_RST_PIN | BUZ_PIN,
        GPIO_PIN_RESET);

    /* TFT control + buzzer as push-pull outputs */
    g.Pin   = TFT_CS_PIN | TFT_DC_PIN | TFT_RST_PIN | BUZ_PIN;
    g.Mode  = GPIO_MODE_OUTPUT_PP;
    g.Pull  = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &g);

    /* SPI1: PA5 (SCK), PA7 (MOSI) — alternate function */
    g.Pin       = GPIO_PIN_5 | GPIO_PIN_7;
    g.Mode      = GPIO_MODE_AF_PP;
    g.Alternate = GPIO_AF5_SPI1;
    g.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    HAL_GPIO_Init(GPIOA, &g);

    /* USART2: PA2 (TX), PA3 (RX) — alternate function */
    g.Pin       = GPIO_PIN_2 | GPIO_PIN_3;
    g.Mode      = GPIO_MODE_AF_PP;
    g.Pull      = GPIO_NOPULL;
    g.Alternate = GPIO_AF7_USART2;
    g.Speed     = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &g);

    /* Keypad lines initialised as pull-up inputs by Keypad_Init() */
}
